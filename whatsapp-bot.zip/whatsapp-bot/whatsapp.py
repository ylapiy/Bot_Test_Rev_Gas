"""Cliente mínimo para a WhatsApp Business Cloud API (Meta)."""
import logging

import requests

log = logging.getLogger(__name__)


class WhatsApp:
    def __init__(self, token: str, phone_number_id: str, api_version: str = "v26.0"):
        self.url = f"https://graph.facebook.com/{api_version}/{phone_number_id}/messages"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    def _post(self, payload: dict) -> dict:
        payload = {"messaging_product": "whatsapp", **payload}
        r = requests.post(self.url, headers=self.headers, json=payload, timeout=15)
        if not r.ok:
            log.error("Erro da API WhatsApp %s: %s", r.status_code, r.text)
        return r.json() if r.content else {}

    # ---------- envio ----------
    def send_text(self, to: str, body: str, preview_url: bool = False) -> dict:
        return self._post({
            "recipient_type": "individual",
            "to": to,
            "type": "text",
            "text": {"body": body[:4096], "preview_url": preview_url},
        })

    def send_buttons(self, to: str, body: str, buttons: list[tuple[str, str]]) -> dict:
        """buttons = [(id, titulo), ...]  -> máx. 3 botões, título até 20 caracteres."""
        if not 1 <= len(buttons) <= 3:
            raise ValueError("O WhatsApp aceita de 1 a 3 botões.")
        return self._post({
            "recipient_type": "individual",
            "to": to,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": body[:1024]},
                "action": {"buttons": [
                    {"type": "reply", "reply": {"id": bid, "title": title[:20]}}
                    for bid, title in buttons
                ]},
            },
        })

    def send_list(self, to: str, body: str, button_label: str,
                  rows: list[tuple[str, str, str]], section_title: str = "Opções") -> dict:
        """Menu em lista. rows = [(id, titulo, descricao), ...] -> máx. 10 itens."""
        return self._post({
            "recipient_type": "individual",
            "to": to,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "body": {"text": body[:4096]},
                "action": {
                    "button": button_label[:20],
                    "sections": [{
                        "title": section_title[:24],
                        "rows": [
                            {"id": rid, "title": t[:24], "description": d[:72]}
                            for rid, t, d in rows[:10]
                        ],
                    }],
                },
            },
        })

    def send_template(self, to: str, name: str, lang: str = "pt_BR",
                      components: list | None = None) -> dict:
        """Templates aprovados: única forma de INICIAR conversa (fora da janela de 24h)."""
        tpl = {"name": name, "language": {"code": lang}}
        if components:
            tpl["components"] = components
        return self._post({"to": to, "type": "template", "template": tpl})

    def mark_as_read(self, message_id: str) -> dict:
        return self._post({"status": "read", "message_id": message_id})
