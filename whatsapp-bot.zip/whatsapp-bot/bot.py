"""Lógica do bot. É AQUI que você personaliza as respostas."""
from whatsapp import WhatsApp

MENU_BUTTONS = [
    ("horario", "Horário"),
    ("precos", "Preços"),
    ("atendente", "Falar c/ atendente"),
]

RESPOSTAS = {
    "horario": "🕘 Atendemos de segunda a sexta, das 9h às 18h.",
    "precos": "💰 Confira nossa tabela de preços: https://seusite.com.br/precos",
    "atendente": "👤 Certo! Um atendente vai falar com você em breve.",
}


def mostrar_menu(wa: WhatsApp, to: str, nome: str = "") -> None:
    saudacao = f"Olá, {nome}! 👋" if nome else "Olá! 👋"
    wa.send_buttons(to, f"{saudacao}\nComo posso ajudar?", MENU_BUTTONS)


def handle_message(wa: WhatsApp, msg: dict, nome: str = "") -> None:
    """Recebe UMA mensagem do webhook e decide o que responder."""
    to = msg["from"]
    tipo = msg.get("type")

    # Clique em botão ou item de lista
    if tipo == "interactive":
        inter = msg["interactive"]
        escolha = (inter.get("button_reply") or inter.get("list_reply") or {}).get("id")
        resposta = RESPOSTAS.get(escolha)
        if resposta:
            wa.send_text(to, resposta, preview_url=True)
            if escolha == "atendente":
                notificar_atendente(to, nome)
        else:
            mostrar_menu(wa, to, nome)
        return

    # Texto digitado
    if tipo == "text":
        texto = msg["text"]["body"].strip().lower()
        if texto in ("oi", "olá", "ola", "menu", "início", "inicio", "bom dia", "boa tarde", "boa noite"):
            mostrar_menu(wa, to, nome)
        elif "hor" in texto:
            wa.send_text(to, RESPOSTAS["horario"])
        elif "preç" in texto or "preco" in texto or "valor" in texto:
            wa.send_text(to, RESPOSTAS["precos"], preview_url=True)
        else:
            wa.send_text(to, "Não entendi 🤔 Escolha uma opção:")
            mostrar_menu(wa, to, nome)
        return

    # Áudio, imagem, figurinha, localização etc.
    wa.send_text(to, "Por enquanto só entendo mensagens de texto. Digite *menu* para ver as opções.")


def notificar_atendente(cliente: str, nome: str) -> None:
    # TODO: integre com seu sistema (e-mail, Slack, planilha, CRM...)
    print(f"[ATENDIMENTO] {nome or 'Cliente'} ({cliente}) pediu um atendente.")
