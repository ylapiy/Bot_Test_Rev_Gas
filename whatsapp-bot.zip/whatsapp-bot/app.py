"""Servidor do webhook (Flask). Rode com:  python app.py"""
import hashlib
import hmac
import logging
import os
from collections import deque

from dotenv import load_dotenv
from flask import Flask, abort, request

from bot import handle_message
from whatsapp import WhatsApp

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("bot")

TOKEN = os.environ["WHATSAPP_TOKEN"]
PHONE_NUMBER_ID = os.environ["PHONE_NUMBER_ID"]
VERIFY_TOKEN = os.environ["VERIFY_TOKEN"]
APP_SECRET = os.getenv("APP_SECRET", "")  # recomendado: valida que o POST veio mesmo da Meta
API_VERSION = os.getenv("API_VERSION", "v26.0")

wa = WhatsApp(TOKEN, PHONE_NUMBER_ID, API_VERSION)
app = Flask(__name__)

# A Meta pode reenviar o mesmo evento; guardamos os últimos IDs para não responder 2x.
_processados = deque(maxlen=1000)


def assinatura_valida(raw: bytes, header: str | None) -> bool:
    if not APP_SECRET:
        return True  # sem APP_SECRET configurado, pula a checagem (ok só para testes)
    if not header or not header.startswith("sha256="):
        return False
    esperado = hmac.new(APP_SECRET.encode(), raw, hashlib.sha256).hexdigest()
    return hmac.compare_digest(esperado, header.removeprefix("sha256="))


@app.get("/webhook")
def verificar():
    """Handshake que a Meta faz ao cadastrar a URL do webhook."""
    if (request.args.get("hub.mode") == "subscribe"
            and request.args.get("hub.verify_token") == VERIFY_TOKEN):
        return request.args.get("hub.challenge", ""), 200
    return "Token de verificação inválido", 403


@app.post("/webhook")
def receber():
    if not assinatura_valida(request.get_data(), request.headers.get("X-Hub-Signature-256")):
        abort(401)

    data = request.get_json(silent=True) or {}
    for entry in data.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            contatos = {c["wa_id"]: c.get("profile", {}).get("name", "")
                        for c in value.get("contacts", [])}

            for msg in value.get("messages", []):
                if msg["id"] in _processados:
                    continue
                _processados.append(msg["id"])
                log.info("Mensagem de %s: %s", msg["from"], msg.get("type"))
                try:
                    wa.mark_as_read(msg["id"])
                    handle_message(wa, msg, contatos.get(msg["from"], ""))
                except Exception:
                    log.exception("Falha ao processar mensagem %s", msg["id"])

            # Status de entrega (sent/delivered/read/failed) chegam aqui:
            for st in value.get("statuses", []):
                if st.get("status") == "failed":
                    log.warning("Falha de entrega: %s", st.get("errors"))

    # Sempre 200 rápido, senão a Meta fica reenviando.
    return "OK", 200


@app.get("/")
def health():
    return "Bot no ar ✅", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
