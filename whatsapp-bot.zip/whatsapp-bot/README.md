# Bot de WhatsApp em Python (Cloud API oficial da Meta)

Sem bibliotecas de terceiros "mágicas": só `requests` + `Flask`, falando direto com a API oficial (Graph API **v26.0**).

```
whatsapp-bot/
├── app.py          # servidor do webhook (recebe mensagens)
├── bot.py          # LÓGICA DO BOT  ← edite aqui
├── whatsapp.py     # cliente da API (texto, botões, lista, template)
├── requirements.txt
└── .env.example
```

## 1. Credenciais (15 min)

1. Acesse <https://developers.facebook.com> → **Meus apps → Criar app** → tipo **Empresa** → adicione o produto **WhatsApp**.
2. Em **WhatsApp → Configuração da API** copie:
   - **Token de acesso temporário** → `WHATSAPP_TOKEN` (expira em 24h, veja o passo 6)
   - **ID do número de telefone** → `PHONE_NUMBER_ID`
3. Ainda nessa tela, em **Para**, adicione e verifique o seu celular (o número de teste só envia para até 5 números cadastrados).
4. Em **Configurações do app → Básico** copie a **Chave secreta do app** → `APP_SECRET`.

## 2. Rodar localmente

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # Windows: copy .env.example .env
# edite o .env com suas credenciais; VERIFY_TOKEN é uma senha que você inventa
python app.py
```

## 3. Expor na internet (ngrok)

```bash
ngrok http 5000
```
Copie a URL `https://xxxx.ngrok-free.app`.

## 4. Cadastrar o webhook

Em **WhatsApp → Configuração → Webhook → Editar**:
- **URL de callback:** `https://xxxx.ngrok-free.app/webhook`
- **Token de verificação:** o mesmo `VERIFY_TOKEN` do `.env`
- Clique em **Verificar e salvar** e depois **assine o campo `messages`** (sem isso nada chega!).

## 5. Testar

Do seu celular, mande **"oi"** para o número de teste. O bot responde com o menu de botões.

## 6. Colocar em produção

- **Token permanente:** Business Manager → **Usuários do sistema** → criar usuário Admin → atribuir o app e a conta do WhatsApp → **Gerar token** com as permissões `whatsapp_business_messaging` e `whatsapp_business_management`.
- **Número real:** adicione e verifique seu número em **WhatsApp → Configuração da API** (não pode estar em uso no app WhatsApp comum, a menos que use coexistência).
- **Hospedagem:** qualquer serviço com HTTPS (Render, Railway, Fly.io, VPS). Comando de start:
  ```bash
  gunicorn -w 2 -b 0.0.0.0:$PORT app:app
  ```
  Configure as variáveis do `.env` no painel do serviço e atualize a URL do webhook.

## Personalizar

Tudo em `bot.py`:
- `MENU_BUTTONS` → botões do menu (máx. **3**, título até **20** caracteres)
- `RESPOSTAS` → texto de cada opção
- `handle_message()` → regras para texto digitado
- Para mais de 3 opções use `wa.send_list(...)` (até 10 itens).

## Regras da Meta que pegam todo mundo

- **Janela de 24h:** você só pode mandar mensagem livre até 24h depois da última mensagem do cliente. Para **iniciar** conversa (ou depois das 24h) é obrigatório usar **template aprovado** → `wa.send_template(numero, "nome_do_template")`.
- **Número no formato internacional, só dígitos:** `5511999998888`.
- **Responda o webhook rápido (200 OK)**; senão a Meta reenvia. O código já evita responder duplicado.
- **Chatbots de IA de uso geral** (tipo "ChatGPT no WhatsApp") são proibidos na API desde 15/01/2026. Bot de atendimento/FAQ/pedidos (mesmo usando IA) é permitido.

## Erros comuns

| Erro | Causa |
|---|---|
| `(#131030) Recipient phone number not in allowed list` | Número não cadastrado em "Para" (modo teste) |
| `Error validating access token` / 401 | Token temporário expirou → gere outro ou use o permanente |
| Webhook não verifica | `VERIFY_TOKEN` diferente ou servidor/ngrok fora do ar |
| Verificou mas não chega nada | Faltou assinar o campo **messages** no webhook |
| 401 no seu servidor | `APP_SECRET` errado (deixe vazio só para testar) |
